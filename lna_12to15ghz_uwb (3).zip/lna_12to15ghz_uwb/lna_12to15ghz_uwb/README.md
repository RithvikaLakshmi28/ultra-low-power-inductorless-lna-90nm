# Ultra-Low Power, High Gain Inductorless LNA Design for IoT Edge Devices

This repository contains the design, schematic netlist, and performance analysis of a 12–15 GHz Ultra-Wideband (UWB) Low Noise Amplifier (LNA) designed in 90nm CMOS technology.

## Overview
IoT edge devices such as smartwatches, environmental sensors, and wearable health monitors process faint RF signals and require low-noise amplification. Standard LNA topologies rely heavily on on-chip inductors, which consume substantial die area and increase production cost. 

This project implements an **inductorless two-stage cascoded LNA architecture** with resistive and inductive degeneration to achieve high gain, low noise figure, and flat frequency response over 12–15 GHz while consuming minimal power.

## Key Features & Performance Metrics

| Parameter | Value | Unit |
| :--- | :--- | :--- |
| **Technology** | 90nm CMOS | - |
| **Frequency Range** | 12 – 15 | GHz |
| **Power Supply ($V_{DD}$)** | 1.2 | V |
| **Power Consumption** | 15 | mW |
| **Power Gain ($S_{21}$)** | 15 ± 1 | dB |
| **Noise Figure (NF)** | 2 – 4 | dB |
| **Architecture** | 2-Stage Cascode | - |

## Key Advantages
- **Battery Conservation:** Consumes only 15 mW at 1.2 V supply voltage.
- **Compact Chip Area:** Inductorless active matching reduces total die footprint.
- **Flat Frequency Response:** Provides consistent $15 \pm 1\text{ dB}$ gain across the entire 12–15 GHz UWB band.
- **Applications:** UWB receivers, low-power radar sensors, and battery-operated IoT edge devices.

## Repository Structure
- `circuit/`: Netlist configuration and schematic diagrams.
- `simulation/`: Testbench configurations and performance results summary.
- `docs/`: Presentation notes and presentation outlines.

## License
Distributed under the MIT License. See `LICENSE` for details.
