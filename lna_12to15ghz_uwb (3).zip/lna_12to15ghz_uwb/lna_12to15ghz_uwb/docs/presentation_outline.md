# Slide Deck Presentation Outline

## Slide 1: Title
- Ultra-Low Power, High Gain Inductorless LNA Design for IoT Edge Devices

## Slide 2: Motivation & Background
- IoT edge devices receive faint signals requiring low-noise amplification.
- Conventional LNAs use large inductors which increase chip size and cost.

## Slide 3: Proposed Architecture
- 90nm CMOS two-stage cascoded topology.
- Inductorless design with resistive & inductive degeneration.

## Slide 4: Simulation Results (12–15 GHz UWB Band)
- Gain ($S_{21}$): 15 ± 1 dB
- Noise Figure: 2 – 4 dB
- Power Consumption: 15 mW at 1.2 V supply

## Slide 5: Conclusion
- Compact, cost-effective, battery-saving solution for IoT receivers and low-power radar sensors.
